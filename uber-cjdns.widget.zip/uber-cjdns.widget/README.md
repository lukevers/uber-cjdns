# uber-cjdns

uber-cjdns is a widget for [Übersicht](http://tracesof.net/uebersicht/)

## Edit

Edit `index.coffee` and change `ipv6` to the address that you are testing your ping connection with. 

## Screenshot

![uber-cjdns](./screenshot.png)
